@org.junit.jupiter.api.Test
void should${NAME}() {
  ${BODY}
  // TODO mat: implement test
  fail("not implemented yet");
}