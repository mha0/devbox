@org.junit.jupiter.api.Test
void ${NAME}() {
  ${BODY}
  fail("TODO mhau: ipmlement test);
}