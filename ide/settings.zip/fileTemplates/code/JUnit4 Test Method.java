@org.junit.Test
public void should${NAME}() {
  ${BODY}
  fail();
}